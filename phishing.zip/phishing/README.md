# phishing_mail


To understand how to send a Python email open this repo:
                  https://github.com/rawanshareef/send_email-_in_python_code
 I opened a temporary email for 10 minutes, according to what you see in the picture after I sent the email, you see that there is inbox mail:
 
![image](https://user-images.githubusercontent.com/73065095/204648548-48c8ac05-ea63-4cc9-806a-409ba4bb5155.png)

Here is the running of the code with the temporary email:

![image](https://user-images.githubusercontent.com/73065095/204648420-a2f667a3-9264-4e6e-854d-d90fc8b39aad.png)


And this is the content of the email sent:
![image](https://user-images.githubusercontent.com/73065095/204647951-335adc8a-db0a-42c0-aae3-20052784c346.png)
